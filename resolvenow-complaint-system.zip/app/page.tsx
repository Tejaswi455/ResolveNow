"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/header"
import { ComplaintForm } from "@/components/complaint-form"
import { MyComplaints } from "@/components/my-complaints"
import { LoginForm } from "@/components/login-form"
import { RegisterForm } from "@/components/register-form"
import { ForgotPasswordForm } from "@/components/forgot-password-form"
import { ComplaintDetail } from "@/components/complaint-detail"
import { AdminDashboard } from "@/components/admin-dashboard"
import { TrackComplaintModal } from "@/components/track-complaint-modal"
import { useAuth } from "@/hooks/use-auth"
import { useTheme } from "@/hooks/use-theme"

export type Section = "home" | "my-complaints" | "login" | "register" | "forgot-password" | "complaint-detail" | "admin"

export default function Home() {
  const [activeSection, setActiveSection] = useState<Section>("home")
  const [selectedComplaintId, setSelectedComplaintId] = useState<string | null>(null)
  const [showTrackModal, setShowTrackModal] = useState(false)
  const { user, isAdmin, isAuthReady } = useAuth()
  const { theme, toggleTheme } = useTheme()

  useEffect(() => {
    if (isAuthReady) {
      if (isAdmin) {
        setActiveSection("admin")
      } else if (user && !user.isAnonymous) {
        setActiveSection("home")
      } else {
        setActiveSection("login")
      }
    }
  }, [user, isAdmin, isAuthReady])

  const handleViewComplaint = (complaintId: string) => {
    setSelectedComplaintId(complaintId)
    setActiveSection("complaint-detail")
  }

  const handleBackToDashboard = () => {
    setSelectedComplaintId(null)
    if (isAdmin) {
      setActiveSection("admin")
    } else {
      setActiveSection("my-complaints")
    }
  }

  const renderSection = () => {
    switch (activeSection) {
      case "home":
        return <ComplaintForm onSuccess={() => setActiveSection("my-complaints")} />
      case "my-complaints":
        return <MyComplaints onViewComplaint={handleViewComplaint} />
      case "login":
        return (
          <LoginForm
            onSwitchToRegister={() => setActiveSection("register")}
            onSwitchToForgot={() => setActiveSection("forgot-password")}
          />
        )
      case "register":
        return <RegisterForm onSwitchToLogin={() => setActiveSection("login")} />
      case "forgot-password":
        return <ForgotPasswordForm onBackToLogin={() => setActiveSection("login")} />
      case "complaint-detail":
        return <ComplaintDetail complaintId={selectedComplaintId} onBack={handleBackToDashboard} />
      case "admin":
        return <AdminDashboard onViewComplaint={handleViewComplaint} />
      default:
        return <ComplaintForm onSuccess={() => setActiveSection("my-complaints")} />
    }
  }

  if (!isAuthReady) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div
      className={`min-h-screen flex flex-col items-center py-8 px-4 sm:px-6 lg:px-8 ${theme === "orange" ? "bg-orange-500 text-white" : "bg-white text-gray-900"}`}
    >
      <Header
        activeSection={activeSection}
        onNavigate={setActiveSection}
        onToggleTheme={toggleTheme}
        onTrackComplaint={() => setShowTrackModal(true)}
        theme={theme}
      />

      <main
        className={`w-full max-w-4xl rounded-xl shadow-lg p-6 sm:p-8 ${theme === "orange" ? "bg-orange-300 text-gray-900" : "bg-white"}`}
      >
        {renderSection()}
      </main>

      <TrackComplaintModal
        isOpen={showTrackModal}
        onClose={() => setShowTrackModal(false)}
        onTrackComplaint={handleViewComplaint}
      />
    </div>
  )
}
