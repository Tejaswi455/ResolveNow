"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { X } from "lucide-react"

interface TrackComplaintModalProps {
  isOpen: boolean
  onClose: () => void
  onTrackComplaint: (id: string) => void
}

export function TrackComplaintModal({ isOpen, onClose, onTrackComplaint }: TrackComplaintModalProps) {
  const [complaintId, setComplaintId] = useState("")
  const [error, setError] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    const id = complaintId.trim()

    if (!id) {
      setError("Please enter a Complaint ID.")
      return
    }

    setError("")
    onTrackComplaint(id)
    setComplaintId("")
    onClose()
  }

  const handleClose = () => {
    setComplaintId("")
    setError("")
    onClose()
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 backdrop-blur-sm">
      <div className="bg-white p-8 rounded-xl shadow-2xl w-90 max-w-md relative transform transition-all duration-300">
        <button
          onClick={handleClose}
          className="absolute top-3 right-3 text-gray-400 hover:text-gray-600 transition-colors"
        >
          <X size={24} />
        </button>

        <h3 className="text-2xl font-bold text-gray-800 mb-4">Track a Complaint</h3>
        <p className="text-gray-700 mb-4">Enter the ID of the complaint you wish to track.</p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="complaintId">Complaint ID</Label>
            <Input
              id="complaintId"
              value={complaintId}
              onChange={(e) => setComplaintId(e.target.value)}
              placeholder="e.g., ABCxyz123"
            />
          </div>

          {error && <p className="text-red-500 text-sm">{error}</p>}

          <Button
            type="submit"
            className="w-full py-3 text-lg font-semibold bg-blue-600 hover:bg-blue-700 transition duration-300 ease-in-out transform hover:scale-105"
          >
            Track Complaint
          </Button>
        </form>
      </div>
    </div>
  )
}
