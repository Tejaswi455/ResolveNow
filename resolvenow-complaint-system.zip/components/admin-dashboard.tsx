"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/hooks/use-auth"
import { Button } from "@/components/ui/button"

interface Complaint {
  id: string
  title: string
  companyName: string
  description: string
  status: "Pending" | "Assigned" | "Resolved" | "Closed"
  timestamp: Date
  userName: string
  userEmail: string
  assignedAgent?: string
}

interface AdminDashboardProps {
  onViewComplaint: (id: string) => void
}

export function AdminDashboard({ onViewComplaint }: AdminDashboardProps) {
  const { isAdmin } = useAuth()
  const [complaints, setComplaints] = useState<Complaint[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (isAdmin) {
      fetchAllComplaints()
    }
  }, [isAdmin])

  const fetchAllComplaints = async () => {
    setLoading(true)
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Mock data for all complaints
    const mockComplaints: Complaint[] = [
      {
        id: "comp-1",
        title: "Poor Customer Service",
        companyName: "TechCorp Inc.",
        description: "The customer service representative was unhelpful and rude.",
        status: "Pending",
        timestamp: new Date("2024-01-15"),
        userName: "John Doe",
        userEmail: "john@example.com",
      },
      {
        id: "comp-2",
        title: "Defective Product",
        companyName: "GadgetWorld",
        description: "The product stopped working after just one week of use.",
        status: "Assigned",
        timestamp: new Date("2024-01-10"),
        userName: "Jane Smith",
        userEmail: "jane@example.com",
        assignedAgent: "Agent Sarah",
      },
      {
        id: "comp-3",
        title: "Billing Error",
        companyName: "ServicePro",
        description: "I was charged twice for the same service.",
        status: "Resolved",
        timestamp: new Date("2024-01-05"),
        userName: "Bob Johnson",
        userEmail: "bob@example.com",
        assignedAgent: "Agent Michael",
      },
    ]

    setComplaints(mockComplaints)
    setLoading(false)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Pending":
        return "text-orange-500"
      case "Assigned":
        return "text-blue-500"
      case "Resolved":
        return "text-green-500"
      case "Closed":
        return "text-gray-500"
      default:
        return "text-gray-500"
    }
  }

  if (!isAdmin) {
    return (
      <div className="text-center">
        <p className="text-red-500">Access Denied: You are not an administrator.</p>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="text-center">
        <p className="text-gray-500">Loading all complaints...</p>
      </div>
    )
  }

  return (
    <section>
      <h2 className="text-3xl font-bold text-gray-800 mb-6 border-b-2 border-purple-500 pb-2 text-center">
        Admin Dashboard
      </h2>

      {complaints.length === 0 ? (
        <p className="text-gray-500 text-center">No complaints registered yet.</p>
      ) : (
        <div className="space-y-4">
          {complaints.map((complaint) => (
            <div
              key={complaint.id}
              className="bg-gray-50 p-4 rounded-lg shadow-md border border-gray-200 hover:shadow-lg transition-shadow"
            >
              <h3 className="text-xl font-semibold text-gray-900 mb-1">{complaint.title}</h3>
              <p className="text-sm text-gray-600 mb-2">
                Company: <span className="font-medium text-blue-700">{complaint.companyName}</span> | Status:{" "}
                <span className={`font-bold ${getStatusColor(complaint.status)}`}>{complaint.status}</span>
              </p>
              <p className="text-sm text-gray-600 mb-2">
                Assigned Agent: <span className="font-medium">{complaint.assignedAgent || "Unassigned"}</span>
              </p>
              <p className="text-gray-700 text-base mb-2 line-clamp-2">{complaint.description}</p>
              <p className="text-xs text-gray-500">
                Submitted by: {complaint.userName} on {complaint.timestamp.toLocaleDateString()}
              </p>
              <Button onClick={() => onViewComplaint(complaint.id)} className="mt-4 bg-purple-500 hover:bg-purple-600">
                Manage Complaint
              </Button>
            </div>
          ))}
        </div>
      )}
    </section>
  )
}
