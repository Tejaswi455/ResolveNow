"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useAuth } from "@/hooks/use-auth"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Complaint {
  id: string
  title: string
  companyName: string
  description: string
  status: "Pending" | "Assigned" | "Resolved" | "Closed"
  timestamp: Date
  userName: string
  userEmail: string
  assignedAgent?: string
  resolutionMessage?: string
}

interface Message {
  id: string
  senderId: string
  senderName: string
  text: string
  timestamp: Date
}

interface ComplaintDetailProps {
  complaintId: string | null
  onBack: () => void
}

export function ComplaintDetail({ complaintId, onBack }: ComplaintDetailProps) {
  const { user, isAdmin } = useAuth()
  const [complaint, setComplaint] = useState<Complaint | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [newMessage, setNewMessage] = useState("")
  const [assignedAgent, setAssignedAgent] = useState("")
  const [resolutionMessage, setResolutionMessage] = useState("")
  const [feedback, setFeedback] = useState({ rating: 5, comments: "" })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (complaintId) {
      fetchComplaintDetails()
      fetchMessages()
    }
  }, [complaintId])

  const fetchComplaintDetails = async () => {
    setLoading(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Mock complaint data
    const mockComplaint: Complaint = {
      id: complaintId!,
      title: "Poor Customer Service",
      companyName: "TechCorp Inc.",
      description:
        "The customer service representative was unhelpful and rude when I called to resolve my billing issue.",
      status: "Assigned",
      timestamp: new Date("2024-01-15"),
      userName: "John Doe",
      userEmail: "john@example.com",
      assignedAgent: "Agent Sarah",
    }

    setComplaint(mockComplaint)
    setAssignedAgent(mockComplaint.assignedAgent || "")
    setResolutionMessage(mockComplaint.resolutionMessage || "")
    setLoading(false)
  }

  const fetchMessages = async () => {
    // Mock messages
    const mockMessages: Message[] = [
      {
        id: "1",
        senderId: "user-123",
        senderName: "John Doe",
        text: "I need help with this issue urgently.",
        timestamp: new Date("2024-01-15T10:00:00"),
      },
      {
        id: "2",
        senderId: "admin-456",
        senderName: "Agent Sarah",
        text: "Hello John, I understand your concern. Let me look into this for you.",
        timestamp: new Date("2024-01-15T10:30:00"),
      },
    ]

    setMessages(mockMessages)
  }

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newMessage.trim()) return

    const message: Message = {
      id: Date.now().toString(),
      senderId: user!.uid,
      senderName: user!.displayName || user!.email || "Anonymous",
      text: newMessage,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, message])
    setNewMessage("")
  }

  const handleAssignAgent = async () => {
    if (!assignedAgent) return

    setComplaint((prev) =>
      prev
        ? {
            ...prev,
            assignedAgent,
            status: "Assigned",
          }
        : null,
    )
  }

  const handleMarkResolved = async () => {
    if (!resolutionMessage) return

    setComplaint((prev) =>
      prev
        ? {
            ...prev,
            status: "Resolved",
            resolutionMessage,
          }
        : null,
    )
  }

  const handleSubmitFeedback = async (e: React.FormEvent) => {
    e.preventDefault()

    setComplaint((prev) =>
      prev
        ? {
            ...prev,
            status: "Closed",
          }
        : null,
    )

    setFeedback({ rating: 5, comments: "" })
  }

  if (loading) {
    return (
      <div className="text-center">
        <p className="text-gray-500">Loading complaint details...</p>
      </div>
    )
  }

  if (!complaint) {
    return (
      <div className="text-center">
        <p className="text-red-500">Complaint not found.</p>
        <Button onClick={onBack} className="mt-4">
          Go Back
        </Button>
      </div>
    )
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Pending":
        return "text-orange-500"
      case "Assigned":
        return "text-blue-500"
      case "Resolved":
        return "text-green-500"
      case "Closed":
        return "text-gray-500"
      default:
        return "text-gray-500"
    }
  }

  return (
    <section>
      <Button onClick={onBack} className="mb-6 bg-gray-200 text-gray-800 hover:bg-gray-300">
        ← Back to Dashboard
      </Button>

      <h2 className="text-3xl font-bold text-gray-800 mb-4 border-b-2 border-blue-500 pb-2">{complaint.title}</h2>

      <div className="space-y-2 mb-6">
        <p className="text-gray-700">
          Company: <span className="font-medium">{complaint.companyName}</span>
        </p>
        <p className="text-gray-700">
          Status: <span className={`font-bold ${getStatusColor(complaint.status)}`}>{complaint.status}</span>
        </p>
        {complaint.assignedAgent && (
          <p className="text-gray-700">
            Assigned To: <span className="font-medium">{complaint.assignedAgent}</span>
          </p>
        )}
        <p className="text-gray-700">
          Submitted by: <span className="font-medium">{complaint.userName}</span> on{" "}
          <span className="font-medium">{complaint.timestamp.toLocaleDateString()}</span>
        </p>
        <p className="text-gray-700">
          Tracking ID No.: <span className="font-medium text-blue-600 select-all">{complaint.id}</span>
        </p>
      </div>

      <div className="bg-gray-100 p-4 rounded-lg border border-gray-200 mb-6">
        <p className="text-gray-800">{complaint.description}</p>
      </div>

      {complaint.resolutionMessage && (
        <div className="bg-blue-50 p-4 rounded-lg shadow-sm mb-6 border border-blue-200">
          <h3 className="text-xl font-bold text-blue-700 mb-2">Resolution:</h3>
          <p className="text-gray-800">{complaint.resolutionMessage}</p>
        </div>
      )}

      {/* Agent Actions */}
      {isAdmin && (
        <div className="bg-red-50 p-4 rounded-lg shadow-sm mb-6 border border-red-200">
          <h3 className="text-xl font-bold text-red-700 mb-4">Agent Actions</h3>
          <div className="space-y-4">
            <div>
              <Label htmlFor="assignAgent">Assign Agent</Label>
              <div className="flex space-x-2">
                <Select value={assignedAgent} onValueChange={setAssignedAgent}>
                  <SelectTrigger className="flex-1">
                    <SelectValue placeholder="Select Agent" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Agent Sarah">Agent Sarah</SelectItem>
                    <SelectItem value="Agent Michael">Agent Michael</SelectItem>
                    <SelectItem value="Agent Emily">Agent Emily</SelectItem>
                  </SelectContent>
                </Select>
                <Button onClick={handleAssignAgent} className="bg-blue-600 hover:bg-blue-700">
                  Assign
                </Button>
              </div>
            </div>

            <div>
              <Label htmlFor="resolutionMessage">Resolution Message</Label>
              <div className="space-y-2">
                <Textarea
                  id="resolutionMessage"
                  rows={3}
                  value={resolutionMessage}
                  onChange={(e) => setResolutionMessage(e.target.value)}
                  className="resize-y"
                />
                <Button onClick={handleMarkResolved} className="bg-green-600 hover:bg-green-700">
                  Mark as Resolved
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Messaging Section */}
      <div className="mt-8">
        <h3 className="text-2xl font-bold text-gray-800 mb-4 border-b-2 border-purple-500 pb-2">Conversation</h3>

        <div className="border border-gray-300 rounded-lg p-4 h-64 overflow-y-auto mb-4 bg-gray-50">
          {messages.length === 0 ? (
            <p className="text-center text-gray-500">No messages yet. Start the conversation!</p>
          ) : (
            <div className="space-y-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`p-3 rounded-lg max-w-[70%] break-words shadow-sm ${
                    message.senderId === user?.uid ? "bg-blue-100 ml-auto text-right" : "bg-gray-100 mr-auto text-left"
                  }`}
                >
                  <p className="font-bold text-sm mb-1">{message.senderName}</p>
                  <p className="text-base">{message.text}</p>
                  <p className="text-xs text-gray-500 mt-1">
                    {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>

        <form onSubmit={handleSendMessage} className="flex space-x-2">
          <Input
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type your message..."
            className="flex-grow"
          />
          <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
            Send
          </Button>
        </form>
      </div>

      {/* Feedback Section */}
      {complaint.status === "Resolved" && complaint.userEmail === user?.email && (
        <div className="mt-8 bg-green-50 p-4 rounded-lg shadow-sm border border-green-200">
          <h3 className="text-xl font-bold text-green-700 mb-4">Provide Feedback</h3>
          <form onSubmit={handleSubmitFeedback} className="space-y-4">
            <div>
              <Label htmlFor="rating">Rating (1-5)</Label>
              <Input
                id="rating"
                type="number"
                min="1"
                max="5"
                value={feedback.rating}
                onChange={(e) => setFeedback((prev) => ({ ...prev, rating: Number.parseInt(e.target.value) }))}
                required
              />
            </div>
            <div>
              <Label htmlFor="comments">Comments</Label>
              <Textarea
                id="comments"
                rows={3}
                value={feedback.comments}
                onChange={(e) => setFeedback((prev) => ({ ...prev, comments: e.target.value }))}
                className="resize-y"
              />
            </div>
            <Button type="submit" className="bg-yellow-600 hover:bg-yellow-700">
              Submit Feedback
            </Button>
          </form>
        </div>
      )}
    </section>
  )
}
