"use client"

import type React from "react"

import { useState } from "react"
import { useAuth } from "@/hooks/use-auth"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"

interface ComplaintFormProps {
  onSuccess: () => void
}

export function ComplaintForm({ onSuccess }: ComplaintFormProps) {
  const { user } = useAuth()
  const [formData, setFormData] = useState({
    companyName: "",
    title: "",
    description: "",
    contactEmail: user?.email || "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return

    setIsSubmitting(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Reset form
    setFormData({
      companyName: "",
      title: "",
      description: "",
      contactEmail: user?.email || "",
    })

    setIsSubmitting(false)
    onSuccess()
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }))
  }

  if (!user) {
    return (
      <div className="text-center">
        <p className="text-red-500">Please log in to submit a complaint.</p>
      </div>
    )
  }

  return (
    <section>
      <h2 className="text-3xl font-bold text-gray-800 mb-6 border-b-2 border-blue-500 pb-2">Submit a New Complaint</h2>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <Label htmlFor="companyName">Company Name</Label>
          <Input id="companyName" name="companyName" value={formData.companyName} onChange={handleChange} required />
        </div>

        <div>
          <Label htmlFor="title">Complaint Title</Label>
          <Input id="title" name="title" value={formData.title} onChange={handleChange} required />
        </div>

        <div>
          <Label htmlFor="description">Detailed Description</Label>
          <Textarea
            id="description"
            name="description"
            rows={5}
            value={formData.description}
            onChange={handleChange}
            required
            className="resize-y"
          />
        </div>

        <div>
          <Label htmlFor="contactEmail">Your Email</Label>
          <Input
            id="contactEmail"
            name="contactEmail"
            type="email"
            value={formData.contactEmail}
            onChange={handleChange}
            required
            readOnly={!user.isAnonymous}
            className={!user.isAnonymous ? "bg-gray-100" : ""}
          />
        </div>

        <Button
          type="submit"
          disabled={isSubmitting}
          className="w-full py-3 text-lg font-semibold bg-blue-600 hover:bg-blue-700 transition duration-300 ease-in-out transform hover:scale-105"
        >
          {isSubmitting ? "Submitting..." : "Submit Complaint"}
        </Button>
      </form>
    </section>
  )
}
