"use client"

import { useAuth } from "@/hooks/use-auth"
import { Button } from "@/components/ui/button"
import type { Section } from "@/app/page"

interface HeaderProps {
  activeSection: Section
  onNavigate: (section: Section) => void
  onToggleTheme: () => void
  onTrackComplaint: () => void
  theme: "white" | "orange"
}

export function Header({ activeSection, onNavigate, onToggleTheme, onTrackComplaint, theme }: HeaderProps) {
  const { user, isAdmin, logout } = useAuth()

  const navLinkClass = (section: Section) =>
    `nav-link px-2 py-0.5 rounded-md hover:bg-white hover:bg-opacity-20 transition-colors duration-200 border-b-2 ${
      activeSection === section ? "border-white" : "border-transparent"
    }`

  console.log("Header - User:", user, "IsAdmin:", isAdmin, "IsAnonymous:", user?.isAnonymous)

  return (
    <header
      className={`w-full max-w-4xl p-6 rounded-xl shadow-lg mb-8 flex flex-col sm:flex-row items-center justify-between ${
        theme === "orange"
          ? "bg-gradient-to-r from-orange-600 to-orange-800 text-white"
          : "bg-gradient-to-r from-blue-600 to-indigo-700 text-white"
      }`}
    >
      <div className="flex flex-col items-center sm:items-start mb-4 sm:mb-0">
        <h1 className="text-4xl font-extrabold cursor-pointer" onClick={() => onNavigate(isAdmin ? "admin" : "home")}>
          ResolveNow
        </h1>
        <p className="text-sm text-white/90 mt-1 whitespace-nowrap">Your direct path to complaint resolution.</p>
      </div>

      <nav className="mt-4 sm:mt-0">
        <ul className="flex space-x-6 text-lg font-semibold">
          <li>
            <button
              onClick={() => onNavigate(isAdmin ? "admin" : "home")}
              className={`${navLinkClass("home")} whitespace-nowrap`}
            >
              Home
            </button>
          </li>
          {user && !user.isAnonymous && (
            <li>
              <button
                onClick={() => onNavigate("my-complaints")}
                className={`${navLinkClass("my-complaints")} whitespace-nowrap`}
              >
                My Complaints
              </button>
            </li>
          )}
          {user && (
            <li>
              <button onClick={onTrackComplaint} className={`${navLinkClass("home")} whitespace-nowrap`}>
                Track Complaint
              </button>
            </li>
          )}
          {user && !user.isAnonymous ? (
            <li>
              <button
                onClick={logout}
                className="px-2 py-0.5 rounded-md bg-red-500 hover:bg-red-600 transition-colors duration-200 whitespace-nowrap"
              >
                Logout
              </button>
            </li>
          ) : (
            <li>
              <button onClick={() => onNavigate("login")} className={`${navLinkClass("login")} whitespace-nowrap`}>
                Login
              </button>
            </li>
          )}
          {isAdmin && (
            <li>
              <button
                onClick={() => onNavigate("admin")}
                className="px-2 py-0.5 rounded-md bg-gray-500 hover:bg-gray-600 transition-colors duration-200 whitespace-nowrap"
              >
                Admin
              </button>
            </li>
          )}
        </ul>
      </nav>

      <Button
        onClick={onToggleTheme}
        className="mt-4 sm:mt-0 ml-0 sm:ml-6 px-2 py-0.5 rounded-md bg-gray-500 hover:bg-gray-600 transition-colors duration-200 whitespace-nowrap text-white"
      >
        Theme
      </Button>
    </header>
  )
}
