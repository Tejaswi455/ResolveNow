"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

interface ForgotPasswordFormProps {
  onBackToLogin: () => void
}

export function ForgotPasswordForm({ onBackToLogin }: ForgotPasswordFormProps) {
  const [email, setEmail] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [message, setMessage] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    // Simulate sending reset email
    await new Promise((resolve) => setTimeout(resolve, 1000))

    setMessage("If an account with that email exists, a password reset link has been sent to your email.")
    setIsLoading(false)
    setEmail("")

    setTimeout(() => {
      onBackToLogin()
    }, 2000)
  }

  return (
    <section>
      <h2 className="text-3xl font-bold text-gray-800 mb-6 border-b-2 border-blue-500 pb-2 text-center">
        Reset Your Password
      </h2>

      <div className="max-w-md mx-auto bg-gray-50 p-8 rounded-xl shadow-md">
        <p className="text-gray-700 text-center mb-6">
          Enter your email address and we'll send you a link to reset your password.
        </p>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="email">Email Address</Label>
            <Input
              id="email"
              name="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          {message && <p className="text-green-600 text-sm text-center">{message}</p>}

          <Button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 text-lg font-semibold bg-purple-600 hover:bg-purple-700 transition duration-300 ease-in-out transform hover:scale-105"
          >
            {isLoading ? "Sending..." : "Send Reset Link"}
          </Button>

          <p className="text-center text-sm">
            Remember your password?{" "}
            <button type="button" onClick={onBackToLogin} className="font-medium text-blue-600 hover:text-blue-500">
              Back to Login
            </button>
          </p>
        </form>
      </div>
    </section>
  )
}
