"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"

interface User {
  uid: string
  email: string | null
  displayName: string | null
  isAnonymous: boolean
}

interface AuthContextType {
  user: User | null
  isAdmin: boolean
  isAuthReady: boolean
  login: (email: string, password: string) => Promise<void>
  register: (email: string, password: string, name: string) => Promise<void>
  logout: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isAdmin, setIsAdmin] = useState(false)
  const [isAuthReady, setIsAuthReady] = useState(false)

  useEffect(() => {
    // Simulate Firebase auth initialization
    const initAuth = async () => {
      // For demo purposes, we'll simulate an anonymous user
      const anonymousUser: User = {
        uid: "anonymous-" + Math.random().toString(36).substr(2, 9),
        email: null,
        displayName: null,
        isAnonymous: true,
      }
      setUser(anonymousUser)
      setIsAuthReady(true)
    }

    initAuth()
  }, [])

  const login = async (email: string, password: string) => {
    // Simulate login
    const loggedInUser: User = {
      uid: "user-" + Math.random().toString(36).substr(2, 9),
      email,
      displayName: email.split("@")[0],
      isAnonymous: false,
    }
    setUser(loggedInUser)
    setIsAdmin(email === "admin@resolvenow.com")
  }

  const register = async (email: string, password: string, name: string) => {
    // Simulate registration
    const newUser: User = {
      uid: "user-" + Math.random().toString(36).substr(2, 9),
      email,
      displayName: name,
      isAnonymous: false,
    }
    setUser(newUser)
    setIsAdmin(email === "admin@resolvenow.com")
  }

  const logout = async () => {
    // Simulate logout and return to anonymous
    const anonymousUser: User = {
      uid: "anonymous-" + Math.random().toString(36).substr(2, 9),
      email: null,
      displayName: null,
      isAnonymous: true,
    }
    setUser(anonymousUser)
    setIsAdmin(false)
  }

  return (
    <AuthContext.Provider
      value={{
        user,
        isAdmin,
        isAuthReady,
        login,
        register,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
